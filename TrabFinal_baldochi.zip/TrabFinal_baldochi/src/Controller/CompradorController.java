/*
 */
package Controller;

import Model.Comprador;
import Model.Util;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rhafaela
 */
public class CompradorController {
    
    static final String nomeDoArquivo = "compradores.txt";
    Comprador c1;
    private ArrayList<Comprador> comprArr;
    
    public Comprador addComprador(Comprador comParam){
        c1 = new Comprador(c1.getCpf(), c1.getNome(),
            c1.getEmail(), c1.getFone(), c1.getContatoPref());
        return c1;
    }
    
    public Comprador addComprador(String pCpf, String pNome, 
            String pEmail, String pFone, String pContatoPref){
        c1 = new Comprador(pCpf, pNome, pEmail, pFone, pContatoPref);
        return c1;
    }
    
    public List<Comprador> consultaCompradores(){
        comprArr = new ArrayList<Comprador>();
        this.lerDoArquivo();
        // lerDoArquivo escreve na variavel comprArr
        return comprArr;
    }
    
    public Comprador consultaComprador(){
        return null;
    }
    
    public void removeComprador(){
        
    }
    
    public void salvarNoArquivo() throws Exception {
        try {
            FileOutputStream arquivo = new FileOutputStream(nomeDoArquivo);
            ObjectOutputStream out = new ObjectOutputStream(arquivo);
            out.writeObject(c1);
            out.flush();
            out.close();
            arquivo.close();
        } catch (Exception exc) {
            throw new Exception("Arquivo Compradores não encontrado!");
        }
    }
    
    public void lerDoArquivo(){
        try {
            FileInputStream arquivo = new FileInputStream(nomeDoArquivo);
            ObjectInputStream in = new ObjectInputStream(arquivo);
            comprArr = (ArrayList<Comprador>) in.readObject();
            in.close();
        } catch (Exception ex) {
            comprArr = new ArrayList<>();
        }
    }
    
    
    //
    public void addTipoImovel(String tipoImovel) throws Exception {
        c1.addTipoImovel(tipoImovel);
    }

    public boolean removeTipoImovel(String tipoImovel) throws Exception {
        boolean res = c1.removeTipoImovel(tipoImovel);
        return res;
    }
    
}
